fc = "".join(f'<div id="s1-fc{i}" class="chip"><b>FC {i}</b><span>센터</span></div>' for i in range(1,6))
base = "".join(f'<i class="blk"></i>' for _ in range(10))
plan = "".join(f'<i class="blk"></i>' for _ in range(10)) + '<i id="s3-extra" class="blk extra"></i>'
cols = "".join(f'<div class="gh">FC {i}</div>' for i in range(1,6))
rows = ""
for r in ["1일","2일","3일","…"]:
    rows += f'<div class="rl">{r}</div>' + "".join('<div class="cell">?</div>' for _ in range(5))
html = f'''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>전국 5개 FC 일별 인력 계획 (가상 시나리오)</title>
<style>
@font-face{{font-family:'NG';src:url('assets/fonts/ng.ttf');font-weight:400}}
@font-face{{font-family:'NG';src:url('assets/fonts/ngb.ttf');font-weight:700}}
:root{{--bg:#0b1322;--panel:#14223d;--ink:#eef3fb;--mute:#9db0cf;--teal:#36d1c4;--amber:#ffb020;--red:#ff5d6c}}
html,body{{margin:0;background:#000}}
#root{{position:relative;width:1920px;height:1080px;overflow:hidden;background:var(--bg);font-family:'NG',sans-serif;color:var(--ink)}}
.bg{{position:absolute;left:0;top:0;width:1920px;height:1080px;background:radial-gradient(1200px 700px at 80% 15%,#18305a 0%,rgba(24,48,90,0) 60%),radial-gradient(900px 600px at 8% 100%,#10333a 0%,rgba(16,51,58,0) 55%)}}
.scene,.sc{{position:absolute;left:0;top:0;width:1920px;height:1080px}}
.tag{{position:absolute;left:192px;top:130px;font-size:42px;color:var(--teal);letter-spacing:2px}}
.h1{{position:absolute;left:192px;top:250px;font-size:210px;font-weight:700;line-height:1.1}}
.sub{{position:absolute;left:192px;top:520px;font-size:62px;color:var(--mute)}}
.chips{{position:absolute;left:192px;top:720px;display:flex;gap:40px}}
.chip{{width:260px;height:150px;border-radius:24px;background:var(--panel);border:3px solid #2b4474;display:flex;flex-direction:column;align-items:center;justify-content:center}}
.chip b{{font-size:60px}} .chip span{{font-size:34px;color:var(--mute)}}
.hd{{position:absolute;left:192px;top:120px;font-size:64px;font-weight:700}}
.stat{{position:absolute;left:192px;top:300px;width:700px}}
.stat .n{{font-size:360px;font-weight:700;line-height:1;color:var(--teal)}}
.stat .l{{font-size:56px;margin-top:10px}} .stat .l2{{font-size:38px;color:var(--mute);margin-top:12px}}
.bars{{position:absolute;left:1000px;top:260px;width:728px;height:640px;display:flex;gap:60px;align-items:flex-end}}
.col{{width:200px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end}}
.col .v{{font-size:64px;font-weight:700;margin-bottom:12px}}
.col .bar{{width:200px;border-radius:18px 18px 0 0}}
.col .nm{{font-size:40px;color:var(--mute);margin-top:16px}}
.rng{{position:absolute;left:1000px;top:130px;font-size:56px;color:var(--amber);font-weight:700}}
.row{{position:absolute;left:192px;display:flex;gap:14px;align-items:center}}
.rowlab{{position:absolute;left:192px;font-size:46px;color:var(--mute)}}
.blk{{display:block;width:90px;height:90px;border-radius:14px;background:var(--teal)}}
.blk.extra{{background:var(--amber)}}
.big10{{position:absolute;left:1100px;top:100px;font-size:120px;font-weight:700;color:var(--amber);line-height:1}}
.big10s{{position:absolute;left:1100px;top:238px;font-size:46px;color:var(--mute)}}
.card{{position:absolute;top:300px;width:740px;height:460px;border-radius:28px;background:var(--panel);border:4px dashed #5a6f99}}
.card h3{{margin:0;position:absolute;left:48px;top:70px;font-size:70px}}
.card p{{margin:0;position:absolute;left:48px;top:200px;font-size:44px;color:var(--mute);width:640px;line-height:1.4}}
.stamp{{position:absolute;right:40px;bottom:40px;padding:10px 34px;border:6px solid var(--red);border-radius:16px;font-size:72px;font-weight:700;color:var(--red)}}
.pill{{position:absolute;top:130px;height:100px;border-radius:50px;padding:0 44px;display:flex;align-items:center;font-size:54px;font-weight:700}}
.grid{{position:absolute;left:192px;top:290px;display:grid;grid-template-columns:110px repeat(5,170px);gap:14px}}
.gh{{height:70px;display:flex;align-items:center;justify-content:center;font-size:42px;color:var(--mute)}}
.rl{{height:100px;display:flex;align-items:center;font-size:42px;color:var(--mute)}}
.cell{{height:100px;border-radius:16px;background:var(--panel);border:3px solid #2b4474;display:flex;align-items:center;justify-content:center;font-size:56px;color:var(--amber);font-weight:700}}
.q{{position:absolute;left:1290px;top:410px;width:440px;white-space:nowrap;font-size:70px;font-weight:700;line-height:1.3;color:var(--amber)}}
.prog{{position:absolute;left:192px;top:1010px;width:1536px;height:8px;border-radius:4px;background:#1b2c4d}}
.prog i{{display:block;width:0;height:8px;border-radius:4px;background:var(--teal)}}
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="30" data-width="1920" data-height="1080">
<div class="bg"></div>

<div id="s1" class="clip scene" data-start="0" data-duration="4.6" data-track-index="1"><div class="sc">
  <div class="tag" id="s1-tag">가상 시나리오 · 풀필먼트 운영본부</div>
  <div class="h1" id="s1-h1">일별 인력 계획</div>
  <div class="sub" id="s1-sub">전국 5개 FC · 날짜별 센터별 필요 인원</div>
  <div class="chips">{fc}</div>
</div></div>

<div id="s2" class="clip scene" data-start="4.6" data-duration="7.1" data-track-index="1"><div class="sc">
  <div class="hd" id="s2-hd">처리량 기준과 물량 변동</div>
  <div class="stat" id="s2-stat"><div class="n" id="s2-n">0</div><div class="l">평균 UPH</div><div class="l2">시간당 처리량</div></div>
  <div class="rng" id="s2-rng">프로모션·명절 물량 1.3 ~ 1.7배</div>
  <div class="bars">
    <div class="col"><div class="v" id="s2-v1">1.0×</div><div class="bar" id="s2-b1" style="background:#4b6aa1"></div><div class="nm">평시</div></div>
    <div class="col"><div class="v" id="s2-v2">1.3×</div><div class="bar" id="s2-b2" style="background:var(--teal)"></div><div class="nm">프로모션</div></div>
    <div class="col"><div class="v" id="s2-v3">1.7×</div><div class="bar" id="s2-b3" style="background:var(--amber)"></div><div class="nm">명절</div></div>
  </div>
</div></div>

<div id="s3" class="clip scene" data-start="11.7" data-duration="4.6" data-track-index="1"><div class="sc">
  <div class="hd" id="s3-hd">현재 계획: 물량 대비 증원</div>
  <div class="rowlab" style="top:330px">기준 인원</div>
  <div class="row" id="s3-r1" style="top:400px">{base}</div>
  <div class="rowlab" style="top:560px">계획 인원</div>
  <div class="row" id="s3-r2" style="top:630px">{plan}</div>
  <div class="big10" id="s3-big">+약 10%</div>
  <div class="big10s" id="s3-bigs">인력 증원</div>
</div></div>

<div id="s4" class="clip scene" data-start="16.3" data-duration="5.2" data-track-index="1"><div class="sc">
  <div class="hd" id="s4-hd">계획에 아직 없는 변수</div>
  <div class="card" id="s4-c1" style="left:192px"><h3>폭염·한파 결근</h3><p>출근 인원이 줄어들 수 있는 요인</p><div class="stamp" id="s4-st1">미반영</div></div>
  <div class="card" id="s4-c2" style="left:988px"><h3>단기 근로자 비중</h3><p>인력 구성이 달라질 수 있는 요인</p><div class="stamp" id="s4-st2">미반영</div></div>
</div></div>

<div id="s5" class="clip scene" data-start="21.5" data-duration="8.5" data-track-index="1"><div class="sc">
  <div class="pill" id="s5-p1" style="left:192px;background:var(--teal);color:#06231f">SLA 99% 준수</div>
  <div class="pill" id="s5-p2" style="left:700px;background:var(--amber);color:#2a1b00">인건비 최소화</div>
  <div class="grid" id="s5-grid"><div></div>{cols}{rows}</div>
  <div class="q" id="s5-q">날짜별<br>센터별<br>필요 인원은?</div>
</div></div>

<div class="prog"><i id="prog-fill"></i></div>

<audio id="a-n1" class="clip" data-start="0.4" data-duration="3.45" src="assets/voice/n1.wav" data-volume="1"></audio>
<audio id="a-n2" class="clip" data-start="4.9" data-duration="6.7" src="assets/voice/n2.wav" data-volume="1"></audio>
<audio id="a-n3" class="clip" data-start="12.0" data-duration="3.65" src="assets/voice/n3.wav" data-volume="1"></audio>
<audio id="a-n4" class="clip" data-start="16.6" data-duration="4.35" src="assets/voice/n4.wav" data-volume="1"></audio>
<audio id="a-n5" class="clip" data-start="21.8" data-duration="7.8" src="assets/voice/n5.wav" data-volume="1"></audio>

<audio id="x-w1" class="clip" data-start="0.05" data-duration="0.57" src="assets/sfx/whoosh-short.mp3" data-volume="0.35"></audio>
<audio id="x-p1" class="clip" data-start="1.3" data-duration="0.72" src="assets/sfx/pop.mp3" data-volume="0.3"></audio>
<audio id="x-w2" class="clip" data-start="4.5" data-duration="0.57" src="assets/sfx/whoosh-short.mp3" data-volume="0.35"></audio>
<audio id="x-g1" class="clip" data-start="6.6" data-duration="1.32" src="assets/sfx/ping.mp3" data-volume="0.3"></audio>
<audio id="x-g2" class="clip" data-start="9.8" data-duration="1.32" src="assets/sfx/ping.mp3" data-volume="0.3"></audio>
<audio id="x-w3" class="clip" data-start="11.6" data-duration="0.57" src="assets/sfx/whoosh-short.mp3" data-volume="0.35"></audio>
<audio id="x-p3" class="clip" data-start="14.3" data-duration="0.72" src="assets/sfx/pop.mp3" data-volume="0.3"></audio>
<audio id="x-w4" class="clip" data-start="16.2" data-duration="0.57" src="assets/sfx/whoosh-short.mp3" data-volume="0.35"></audio>
<audio id="x-n4a" class="clip" data-start="18.0" data-duration="1.32" src="assets/sfx/ping.mp3" data-volume="0.3"></audio>
<audio id="x-n4b" class="clip" data-start="20.2" data-duration="0.72" src="assets/sfx/pop.mp3" data-volume="0.3"></audio>
<audio id="x-w5" class="clip" data-start="21.4" data-duration="0.57" src="assets/sfx/whoosh-short.mp3" data-volume="0.35"></audio>
<audio id="x-im" class="clip" data-start="27.6" data-duration="1.4" data-fade-out="0.4" src="assets/sfx/impact-bass-1.mp3" data-volume="0.4"></audio>
</div>
<script src="assets/gsap.min.js"></script>
<script>
const tl = gsap.timeline({{ paused: true }});
const T = {{ s1:[0,4.6], s2:[4.6,11.7], s3:[11.7,16.3], s4:[16.3,21.5], s5:[21.5,30] }};
Object.entries(T).forEach(([id,[a,b]]) => {{
  if (id!=='s1') tl.fromTo('#'+id+' .sc', {{opacity:0,x:60}}, {{opacity:1,x:0,duration:.35,ease:'power3.out'}}, a);
  if (id!=='s5') tl.to('#'+id+' .sc', {{opacity:0,x:-60,duration:.25,ease:'power2.in'}}, b-0.3);
}});
tl.to('#prog-fill', {{width:1536,duration:30,ease:'none'}}, 0);

// S1
tl.fromTo('#s1-h1', {{y:24}}, {{y:0,duration:.6,ease:'power3.out'}}, 0);
[1,2,3,4,5].forEach((i,k) => tl.fromTo('#s1-fc'+i, {{opacity:0,scale:.6}}, {{opacity:1,scale:1,duration:.3,ease:'back.out(2)'}}, 1.3+k*0.25));

// S2
const o = {{v:0}};
tl.fromTo('#s2-hd', {{opacity:0,y:20}}, {{opacity:1,y:0,duration:.4}}, 4.8);
tl.fromTo('#s2-stat', {{opacity:0,y:30}}, {{opacity:1,y:0,duration:.4}}, 5.1);
tl.to(o, {{v:38,duration:1.4,ease:'power2.out',onUpdate:()=>{{document.getElementById('s2-n').textContent=Math.round(o.v);}}}}, 5.3);
[['b1',300,7.7],['b2',390,8.6],['b3',510,9.8]].forEach(([id,h,t],k) => {{
  tl.fromTo('#s2-'+id, {{height:0}}, {{height:h,duration:.6,ease:'power3.out'}}, t);
  tl.fromTo('#s2-v'+(k+1), {{opacity:0}}, {{opacity:1,duration:.3}}, t+0.3);
}});
tl.fromTo('#s2-rng', {{opacity:0,x:30}}, {{opacity:1,x:0,duration:.45}}, 8.2);

// S3
tl.fromTo('#s3-hd', {{opacity:0,y:20}}, {{opacity:1,y:0,duration:.4}}, 11.9);
tl.fromTo('#s3-r1 .blk', {{opacity:0,scale:.5}}, {{opacity:1,scale:1,duration:.25,stagger:.04}}, 12.2);
tl.fromTo('#s3-r2 .blk', {{opacity:0,scale:.5}}, {{opacity:1,scale:1,duration:.25,stagger:.04}}, 13.0);
tl.fromTo('#s3-extra', {{scale:.2}}, {{scale:1,duration:.4,ease:'back.out(3)'}}, 14.3);
tl.fromTo('#s3-big', {{opacity:0,x:40}}, {{opacity:1,x:0,duration:.45,ease:'power3.out'}}, 14.3);
tl.fromTo('#s3-bigs', {{opacity:0}}, {{opacity:1,duration:.3}}, 14.7);

// S4
tl.fromTo('#s4-hd', {{opacity:0,y:20}}, {{opacity:1,y:0,duration:.4}}, 16.5);
tl.fromTo('#s4-c1', {{opacity:0,y:40}}, {{opacity:1,y:0,duration:.45,ease:'power3.out'}}, 16.7);
tl.fromTo('#s4-c2', {{opacity:0,y:40}}, {{opacity:1,y:0,duration:.45,ease:'power3.out'}}, 18.6);
tl.fromTo('#s4-st1', {{opacity:0,scale:2.2,rotation:-14}}, {{opacity:1,scale:1,rotation:-8,duration:.3,ease:'power4.out'}}, 18.0);
tl.fromTo('#s4-st2', {{opacity:0,scale:2.2,rotation:-14}}, {{opacity:1,scale:1,rotation:-8,duration:.3,ease:'power4.out'}}, 20.2);

// S5
tl.fromTo('#s5-p1', {{opacity:0,y:-20}}, {{opacity:1,y:0,duration:.4}}, 22.2);
tl.fromTo('#s5-p2', {{opacity:0,y:-20}}, {{opacity:1,y:0,duration:.4}}, 24.8);
tl.fromTo('#s5-grid', {{opacity:0,y:30}}, {{opacity:1,y:0,duration:.5}}, 25.6);
tl.fromTo('#s5-grid .cell', {{opacity:0,scale:.7}}, {{opacity:1,scale:1,duration:.25,stagger:.07}}, 26.5);
tl.fromTo('#s5-q', {{opacity:0,x:40}}, {{opacity:1,x:0,duration:.5,ease:'power3.out'}}, 27.6);
window.__timelines = window.__timelines || {{}};
window.__timelines['main'] = tl;
</script>
</body>
</html>
'''
open('index.html','w',encoding='utf-8').write(html)
