import re, base64, json
src = open('index.html', encoding='utf-8').read()
b64 = lambda p: base64.b64encode(open(p,'rb').read()).decode()

# 1) markup: root contents up to the first <audio>
root = src[src.index('<div id="root"'):src.index('<audio')]
root = root.replace('class="clip scene"', 'class="scene"')
root = re.sub(r'\sdata-(start|duration|track-index|width|height|composition-id)="[^"]*"', '', root)
root += '</div>'  # close #root

# 2) audio cues from index.html
cues = []
for m in re.finditer(r'<audio id="([^"]+)"[^>]*?data-start="([^"]+)"[^>]*?src="([^"]+)"[^>]*?data-volume="([^"]+)"', src):
    i, st, p, vol = m.groups()
    if p.startswith('assets/voice/'):
        p = '/tmp/pa/' + p.split('/')[-1].replace('.wav', '.mp3')
        kind = 'voice'
    else:
        kind = 'sfx'
    cues.append(dict(id=i, t=float(st), v=float(vol), k=kind, d='data:audio/mpeg;base64,' + b64(p)))

# 3) timeline script from index.html (drop registration lines)
js = re.search(r'<script>\n(const tl = .*?)window\.__timelines', src, re.S).group(1)
gsap = open('assets/gsap.min.js', encoding='utf-8').read()

css = re.search(r'<style>(.*?)</style>', src, re.S).group(1)
css = re.sub(r"@font-face\{[^}]*\}\s*", "", css)
fonts = (f"@font-face{{font-family:'NG';src:url(data:font/ttf;base64,{b64('assets/fonts/ng.ttf')});font-weight:400}}"
         f"@font-face{{font-family:'NG';src:url(data:font/ttf;base64,{b64('assets/fonts/ngb.ttf')});font-weight:700}}")

player_css = """
html,body{margin:0;height:100%;background:#050a14;font-family:'NG',sans-serif}
#wrap{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;gap:16px;padding:12px;box-sizing:border-box}
#frame{position:relative;overflow:hidden;border-radius:10px;box-shadow:0 8px 40px rgba(0,0,0,.6)}
#stage{position:absolute;left:0;top:0;transform-origin:0 0}
#ctl{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;align-items:center}
#ctl button{font-family:'NG',sans-serif;font-size:18px;font-weight:700;color:#eef3fb;background:#14223d;border:2px solid #2b4474;border-radius:12px;padding:10px 20px;cursor:pointer}
#ctl button:hover{border-color:#36d1c4}
#ctl button.on{background:#36d1c4;color:#06231f;border-color:#36d1c4}
#clock{color:#9db0cf;font-size:16px;min-width:90px;text-align:center}
#hint{color:#9db0cf;font-size:14px}
"""

player_js = """
const CUES = __CUES__;
const scenes = Object.keys(T);
function showOnly(id){ scenes.forEach(s=>document.getElementById(s).style.display = (s===id?'block':'none')); }
showOnly('s1');
scenes.forEach(id=>{ const [a,b]=T[id]; if(id!=='s1') tl.set('#'+id,{display:'block',immediateRender:false},a); if(id!=='s5') tl.set('#'+id,{display:'none',immediateRender:false},b); });
const auds = CUES.map(c=>{ const a=new Audio(c.d); a.preload='auto'; a.volume=Math.min(1,c.v); return {c,a}; });
let narrOn = true, playing = false;
const $ = id => document.getElementById(id);
function applyMute(){ auds.forEach(x=>{ if(x.c.k==='voice') x.a.muted = !narrOn; }); }
function stopAudio(){ auds.forEach(x=>{ x.a.pause(); try{x.a.currentTime=0;}catch(e){} }); }
auds.forEach(x=>tl.call(()=>{ if(playing){ try{x.a.currentTime=0;}catch(e){} x.a.play().catch(()=>{}); } }, null, x.c.t));
function fit(){ const f=$('frame'); const w=Math.min(window.innerWidth-24, (window.innerHeight-120)*16/9); f.style.width=w+'px'; f.style.height=(w*9/16)+'px'; $('stage').style.transform='scale('+(w/1920)+')'; }
window.addEventListener('resize',fit); fit();
function setUI(){ $('play').classList.toggle('on',playing); $('narr').textContent = narrOn ? '🔊 나레이션 켜짐' : '🔇 나레이션 꺼짐'; $('narr').classList.toggle('on',narrOn); }
function prime(){ auds.forEach(x=>{ const m=x.a.muted; x.a.muted=true; x.a.play().then(()=>{ x.a.pause(); x.a.currentTime=0; x.a.muted=m; applyMute(); }).catch(()=>{ x.a.muted=m; }); }); }
let primed=false;
$('play').onclick = () => { if(playing) return; if(!primed){ prime(); primed=true; }
  setTimeout(()=>{ playing=true; applyMute(); if(tl.progress()>=1) tl.progress(0); tl.play(); setUI(); }, primed?0:120); };
$('stop').onclick = () => { playing=false; tl.pause(0); stopAudio(); showOnly('s1'); $('clock').textContent='0.0 / 30.0 s'; setUI(); };
$('narr').onclick = () => { narrOn=!narrOn; applyMute(); setUI(); };
tl.eventCallback('onUpdate',()=>{ $('clock').textContent = tl.time().toFixed(1)+' / 30.0 s'; });
tl.eventCallback('onComplete',()=>{ playing=false; setUI(); });
setUI(); applyMute();
"""
player_js = player_js.replace('__CUES__', json.dumps(cues, ensure_ascii=False))

html = f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>전국 5개 FC 일별 인력 계획 (가상 시나리오) — 인터랙티브 플레이어</title>
<style>{fonts}{css}{player_css}</style></head>
<body><div id="wrap">
<div id="frame"><div id="stage">{root}</div></div>
<div id="ctl"><button id="play">▶ 재생</button><button id="stop">■ 중지</button><button id="narr">🔊 나레이션 켜짐</button><span id="clock">0.0 / 30.0 s</span></div>
<div id="hint">가상 시나리오 · 중지를 누르면 처음 화면으로 돌아갑니다</div>
</div>
<script>{gsap}</script>
<script>
{js}
{player_js}
</script></body></html>"""
open('player.html', 'w', encoding='utf-8').write(html)
print(len(html)//1024, 'KB', len(cues), 'cues')
