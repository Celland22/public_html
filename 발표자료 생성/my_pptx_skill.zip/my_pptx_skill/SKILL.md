---
name: my_pptx_skill
description: 한림대학교 생명과학과 이종건 학생의 대학원 발표(논문 리뷰/저널클럽, 랩미팅·연구 진행상황, 학회·세미나 발표, 학위논문 계획·심사)용 PowerPoint(.pptx)를 Arrow Rings 템플릿으로 만든다. 사용자가 발표자료, 슬라이드, PPT, pptx, 저널클럽, 랩미팅, 세미나, 학위논문 심사 자료를 요청하면 반드시 이 스킬을 사용한다.
---

# my_pptx_skill

대학원 생활용 발표자료 생성 스킬. 템플릿: PresentationGO "Arrow Rings" (4:3, 진청록 배경 + 골드 제목 + 민트 화살표).

## 고정 사양 (사용자와 확정됨)
| 항목 | 내용 |
|---|---|
| 발표자 | 이종건 / 한림대학교 생명과학과 |
| 1번 슬라이드 | 발표 제목 + 발표자 (Cover 레이아웃) |
| 2번 슬라이드 | 목차 (섹션 제목을 자동 번호로 나열) |
| 본문 | 간결한 **개조식** 텍스트 (Title and Content 레이아웃) |
| 마지막 슬라이드 | "질문 및 토의 Q&A" + 토론 유도 질문 2~3개 + 연락처(이메일) (Closing 레이아웃) |
| 폰트 | 한글 맑은 고딕 / 영문 Calibri (템플릿 테마) |
| 푸터 | "한림대학교 생명과학과 · 이종건" + 쪽번호(왼쪽 하단). 날짜는 사용 안 함 |
| 섹션 슬라이드 | 본문이 **8장 이상**일 때만 섹션별로 자동 삽입 |

## 작업 절차
1. `references/writing_guide.md`를 읽고 발표 유형(논문 리뷰 / 랩미팅 / 학회·세미나 / 학위논문 계획)에 맞는 구성을 정한다.
2. 발표 주제·분량·유형이 불명확하면 사용자에게 먼저 짧게 묻는다. 이메일이 `assets/config.json`에 비어 있으면 한 번 물어서 채운다.
3. `references/content_schema.md` 형식으로 content JSON을 작성한다 (`assets/example_content.json` 참고).
4. 빌드: `python scripts/build_deck.py content.json /mnt/user-data/outputs/<이름>.pptx`
   - 의존성: `python-pptx`, `lxml`. 경고(WARN: 서술형 종결, 긴 문장, 불릿 과다)가 나오면 JSON을 고쳐 다시 빌드한다.
5. 검수: 이미지로 렌더링해 텍스트 넘침·겹침을 확인한다 (`scripts/render_preview.sh`). 문제가 있으면 문장을 줄이거나 슬라이드를 나눈다.
6. 결과 파일을 사용자에게 전달한다.

## 규칙
- 본문은 **개조식**: 명사형/체언 종결, 한 줄 45자 이내, 슬라이드당 불릿 3~6개, 들여쓰기는 최대 1단계.
- 서술형 종결(~합니다, ~이다)과 마침표를 쓰지 않는다.
- 영어 전문용어·유전자·종명은 원문 표기 유지 (예: *Cas9*, GUIDE-seq).
- 템플릿의 레이아웃·색·폰트를 임의로 바꾸지 않는다 (디자인은 `references/design_guide.md`).
- 슬라이드 하나에 메시지 하나. 내용이 넘치면 슬라이드를 분리한다.
- 발표 노트는 `notes` 필드에 넣으면 슬라이드 노트로 들어간다.

## 파일 구성
- `assets/template.potx` : 원본 템플릿 (수정 금지)
- `assets/config.json` : 발표자·소속·이메일·푸터·폰트·섹션 기준
- `assets/example_content.json` : 입력 예시
- `references/` : 작성 가이드, 디자인 가이드, JSON 스키마
- `scripts/build_deck.py` : 빌더 / `scripts/render_preview.sh` : 미리보기 렌더링
