# content JSON 스키마

```json
{
  "title": "발표 제목",
  "date": "2026. 10. 07.",          // 선택
  "presenter": "이종건",             // 선택 (기본: config.json)
  "email": "name@hallym.ac.kr",     // 선택 (기본: config.json)
  "sections": [
    {
      "title": "섹션 제목(목차에 표시)",
      "subtitle": "섹션 슬라이드 부제",   // 선택, 섹션 슬라이드 사용 시
      "slides": [
        {
          "title": "슬라이드 제목",
          "bullets": [
            "1단계 불릿",
            {"text": "2단계 불릿", "level": 1}
          ],
          "layout": "narrow",       // 선택: 글상자를 좁게 하고 오른쪽에 화살표 그림 강조
          "font_size": 20,          // 선택: 기본 20
          "notes": "발표 노트"       // 선택
        }
      ]
    }
  ],
  "closing": {
    "title": "질문 및 토의 Q&A",
    "questions": ["토론 유도 질문 1 (25자 이내)", "토론 유도 질문 2"]
  }
}
```

## 자동 처리
- 1번 Cover, 2번 목차, 마지막 Closing은 자동 생성된다.
- 본문 슬라이드 합계 ≥ 8장이면 섹션마다 Section 슬라이드가 삽입된다 (기준: config.json의 `section_slide_min_body_slides`).
- 제목 길이에 따라 Cover 제목 크기가 자동 조절된다 (12자 이하 40pt → 33자 이상 24pt).
- Closing 질문은 최대 3개, 각 25자 이내 권장 (글상자가 작음).
