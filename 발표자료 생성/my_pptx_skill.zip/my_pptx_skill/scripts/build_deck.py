#!/usr/bin/env python3
"""my_pptx_skill - content JSON -> .pptx (Arrow Rings template).

Usage:  python build_deck.py content.json output.pptx [--config ../assets/config.json]
"""
import argparse, copy, io, json, re, sys, zipfile
from pathlib import Path
from lxml import etree
from pptx import Presentation
from pptx.util import Pt

HERE = Path(__file__).resolve().parent
ASSETS = HERE.parent / "assets"
NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"

def load_template(korean_font):
    """.potx -> in-memory .pptx (content type patch) + theme East-Asian font = Korean font."""
    src = zipfile.ZipFile(ASSETS / "template.potx")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as out:
        for item in src.infolist():
            data = src.read(item.filename)
            if item.filename == "[Content_Types].xml":
                data = data.replace(b"presentationml.template.main+xml",
                                    b"presentationml.presentation.main+xml")
            elif re.match(r"ppt/theme/theme\d+\.xml", item.filename):
                s = data.decode("utf-8")
                s = re.sub(r'<a:ea typeface="[^"]*"/>', f'<a:ea typeface="{korean_font}"/>', s)
                s = re.sub(r'(<a:font script="Hang" typeface=")[^"]*(")', rf"\g<1>{korean_font}\2", s)
                data = s.encode("utf-8")
            out.writestr(item, data)
    buf.seek(0)
    return Presentation(buf)

def layout(prs, name):
    for l in prs.slide_layouts:
        if l.name == name:
            return l
    raise KeyError(name)

def ph(slide, idx):
    for s in slide.placeholders:
        if s.placeholder_format.idx == idx:
            return s
    return None

def set_runs(par, text, font, size=None, bold=None):
    r = par.add_run(); r.text = text
    rPr = r._r.get_or_add_rPr(); rPr.set("lang", "ko-KR")
    ea = etree.SubElement(rPr, f"{{{NS_A}}}ea"); ea.set("typeface", font)
    if size: r.font.size = Pt(size)
    if bold is not None: r.font.bold = bold
    return r

def fill(shape, lines, font, size=None):
    tf = shape.text_frame; tf.clear()
    for i, line in enumerate(lines):
        text, level = (line, 0) if isinstance(line, str) else (line["text"], line.get("level", 0))
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.level = level
        set_runs(p, text, font, size)

def add_footer(slide, lay, cfg, with_number=True):
    """Layout footer/slide-number placeholders are not auto-copied: clone them."""
    for s in lay.placeholders:
        name = str(s.placeholder_format.type)
        if "FOOTER" in name or ("SLIDE_NUMBER" in name and with_number):
            el = copy.deepcopy(s._element)
            ids = [int(i) for i in slide.shapes._spTree.xpath("//p:cNvPr/@id")]
            el.xpath(".//p:cNvPr")[0].set("id", str(max(ids + [1]) + 1))
            for e in el.xpath(".//a:extLst"): e.getparent().remove(e)
            slide.shapes._spTree.append(el)
            if "SLIDE_NUMBER" in name and lay.name != "Section 2":
                # 오른쪽 하단은 화살표 그림에 가려지므로 날짜 자리(왼쪽 하단)로 이동
                el.xpath(".//a:off")[0].set("x", "628650")
                p0 = el.xpath(".//a:p")[0]
                pp = p0.find(f"{{{NS_A}}}pPr")
                if pp is None:
                    pp = etree.Element(f"{{{NS_A}}}pPr"); p0.insert(0, pp)
                pp.set("algn", "l")
            for t in el.iter(f"{{{NS_A}}}t"):
                if t.text and "‹#›" in t.text: t.text = str(len(slide.part.package.presentation_part.presentation.slides))
            if "FOOTER" in name:
                p = el.find(f"{{{NS_P}}}txBody").find(f"{{{NS_A}}}p")
                for r in p.findall(f"{{{NS_A}}}r"): p.remove(r)
                r = etree.Element(f"{{{NS_A}}}r")
                rPr = etree.SubElement(r, f"{{{NS_A}}}rPr"); rPr.set("lang", "ko-KR")
                etree.SubElement(rPr, f"{{{NS_A}}}ea").set("typeface", cfg["korean_font"])
                etree.SubElement(r, f"{{{NS_A}}}t").text = cfg["footer_text"]
                end = p.find(f"{{{NS_A}}}endParaRPr")
                if end is not None: end.addprevious(r)
                else: p.append(r)

def title_size(text, big=40):
    n = len(text)
    return big if n <= 12 else big - 6 if n <= 20 else big - 12 if n <= 32 else big - 16

LINT_END = re.compile(r"(합니다|입니다|했다|이다|한다|된다|있다|없다|였다|됩니다|습니다)\.?$")

def lint(content, warnings):
    for sec in content["sections"]:
        for sl in sec["slides"]:
            b = sl["bullets"]
            if len(b) > 6: warnings.append(f"[{sl['title']}] 불릿 {len(b)}개 (권장 ≤6)")
            for x in b:
                t = x if isinstance(x, str) else x["text"]
                if len(t) > 45: warnings.append(f"[{sl['title']}] 너무 긴 문장({len(t)}자): {t[:20]}…")
                if LINT_END.search(t.strip()): warnings.append(f"[{sl['title']}] 개조식 아님(서술형 종결): {t[:24]}…")

def build(content, cfg, out):
    prs = load_template(cfg["korean_font"])
    lst = prs.slides._sldIdLst
    for sid in list(lst):
        prs.part.drop_rel(sid.rId); lst.remove(sid)
    f = cfg["korean_font"]
    warnings = []; lint(content, warnings)
    n_body = sum(len(s["slides"]) for s in content["sections"])
    use_sections = n_body >= cfg["section_slide_min_body_slides"]

    # 1. Cover
    L = layout(prs, "Cover"); s = prs.slides.add_slide(L)
    t = content["title"]
    fill(ph(s, 0), [t], f, title_size(t))
    tf = ph(s, 1).text_frame; tf.clear()
    set_runs(tf.paragraphs[0], f"발표자  {content.get('presenter', cfg['presenter'])}", f, 18, True)
    for extra in (cfg["affiliation"], content.get("date", "")):
        if extra:
            set_runs(tf.add_paragraph(), extra, f, 14)

    # 2. TOC
    L = layout(prs, "Title and Content 1"); s = prs.slides.add_slide(L)
    fill(ph(s, 0), ["목차"], f, 32)
    tf = ph(s, 1).text_frame; tf.clear()
    for i, sec in enumerate(content["sections"], 1):
        p = tf.paragraphs[0] if i == 1 else tf.add_paragraph()
        pPr = p._p.get_or_add_pPr()
        pPr.set("marL", "0"); pPr.set("indent", "0")
        etree.SubElement(pPr, f"{{{NS_A}}}buNone")
        set_runs(p, f"{i:02d}   {sec['title']}", f, 24 if len(content['sections']) <= 5 else 20)
        p.space_after = Pt(14)
    add_footer(s, L, cfg)

    # 3. Body
    for i, sec in enumerate(content["sections"], 1):
        if use_sections:
            L = layout(prs, "Section 1" if i % 2 else "Section 2"); s = prs.slides.add_slide(L)
            fill(ph(s, 0), [f"{i:02d}. {sec['title']}"], f, 32)
            if ph(s, 1) is not None: fill(ph(s, 1), [sec.get("subtitle", "")], f, 16)
            add_footer(s, L, cfg)
        for sl in sec["slides"]:
            L = layout(prs, "Title and Content 2" if sl.get("layout") == "narrow" else "Title and Content 1")
            s = prs.slides.add_slide(L)
            fill(ph(s, 0), [sl["title"]], f, 32)
            fill(ph(s, 1), sl["bullets"], f, sl.get("font_size", 20))
            add_footer(s, L, cfg)
            if sl.get("notes"): s.notes_slide.notes_text_frame.text = sl["notes"]

    # 4. Closing (question prompt)
    cl = content.get("closing", {})
    L = layout(prs, "Closing"); s = prs.slides.add_slide(L)
    fill(ph(s, 0), [cl.get("title", "질문 및 토의 Q&A")], f, 40)
    qs = cl.get("questions", [])
    fill(ph(s, 1), [f"Q{i}. {q}" for i, q in enumerate(qs, 1)] or ["질문 있으신가요?"], f, 14)
    email = content.get("email", cfg.get("email", ""))
    contacts = {14: content.get("presenter", cfg["presenter"]), 15: email, 16: cfg["affiliation"]}
    for idx, val in contacts.items():
        p = ph(s, idx)
        if p is None: continue
        if val: fill(p, [val], f, 11)
        else: p._element.getparent().remove(p._element)
    if not email: warnings.append("이메일 미설정: assets/config.json 의 email 을 채우세요")
    add_footer(s, L, cfg)

    prs.save(out)
    for w in warnings: print("WARN", w, file=sys.stderr)
    print(f"saved {out}  ({len(prs.slides)} slides, section slides={'on' if use_sections else 'off'})")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("content"); ap.add_argument("output")
    ap.add_argument("--config", default=str(ASSETS / "config.json"))
    a = ap.parse_args()
    cfg = json.load(open(a.config, encoding="utf-8"))
    build(json.load(open(a.content, encoding="utf-8")), cfg, a.output)
