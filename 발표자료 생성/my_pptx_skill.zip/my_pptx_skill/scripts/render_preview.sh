#!/bin/bash
# 사용법: render_preview.sh deck.pptx [출력폴더]  -> 슬라이드별 JPG 생성 (LibreOffice + pdftoppm 필요)
set -e
IN="$1"; OUT="${2:-preview}"; mkdir -p "$OUT"
soffice --headless --convert-to pdf --outdir "$OUT" "$IN" >/dev/null 2>&1
pdftoppm -jpeg -r 80 "$OUT/$(basename "${IN%.*}").pdf" "$OUT/slide"
ls "$OUT"
