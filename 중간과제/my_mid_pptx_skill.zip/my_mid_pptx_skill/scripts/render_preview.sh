#!/usr/bin/env bash
# PPTX -> PDF -> JPG 미리보기. LibreOffice(soffice)와 poppler(pdftoppm) 필요.
# 사용: bash render_preview.sh deck.pptx [출력폴더]
set -e
IN="$1"; OUT="${2:-./preview}"
[ -f "$IN" ] || { echo "사용: bash render_preview.sh deck.pptx [출력폴더]"; exit 1; }
mkdir -p "$OUT"
SOFFICE="soffice"
# Claude 샌드박스용 래퍼가 있으면 사용
[ -f /mnt/skills/public/pptx/scripts/office/soffice.py ] && SOFFICE="python3 /mnt/skills/public/pptx/scripts/office/soffice.py"
$SOFFICE --headless --convert-to pdf --outdir "$OUT" "$IN" >/dev/null 2>&1
PDF="$OUT/$(basename "${IN%.*}").pdf"
rm -f "$OUT"/slide-*.jpg
pdftoppm -jpeg -r 80 "$PDF" "$OUT/slide"
ls -1 "$(cd "$OUT" && pwd)"/slide-*.jpg
