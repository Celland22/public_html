#!/usr/bin/env python3
"""기본 네이비 그라데이션 배경(표지/마지막 슬라이드용)을 생성한다.

사용:  python gen_background.py [출력_폴더]
결과:  bg_cover_default.png, bg_closing_default.png (1920x1080)
"""
import os
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W, H = 1920, 1080
NAVY = np.array([0x0D, 0x1B, 0x33], dtype=float)
DEEP = np.array([0x17, 0x3B, 0x6D], dtype=float)
COBALT = np.array([0x27, 0x77, 0xD6], dtype=float)


def make(seed_shift=0.0, glow_xy=(0.82, 0.30)):
    yy, xx = np.mgrid[0:H, 0:W]
    t = (xx / W * 0.55 + yy / H * 0.45)          # 대각선 그라데이션
    t = np.clip(t + seed_shift, 0, 1)[..., None]
    base = NAVY * (1 - t) + DEEP * t
    gx, gy = glow_xy[0] * W, glow_xy[1] * H       # 코발트 글로우
    d = np.sqrt((xx - gx) ** 2 + (yy - gy) ** 2) / (W * 0.45)
    glow = np.clip(1 - d, 0, 1)[..., None] ** 2
    img = base * (1 - 0.55 * glow) + COBALT * (0.55 * glow)
    im = Image.fromarray(img.astype("uint8"), "RGB").convert("RGBA")

    # 은은한 격자/원형 라인 장식
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dr = ImageDraw.Draw(layer)
    for r in range(260, 1100, 170):
        dr.ellipse([gx - r, gy - r, gx + r, gy + r], outline=(68, 188, 237, 26), width=2)
    for x in range(0, W, 120):
        dr.line([(x, 0), (x, H)], fill=(255, 255, 255, 8), width=1)
    for y in range(0, H, 120):
        dr.line([(0, y), (W, y)], fill=(255, 255, 255, 8), width=1)
    layer = layer.filter(ImageFilter.GaussianBlur(0.6))
    return Image.alpha_composite(im, layer).convert("RGB")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "assets")
    os.makedirs(out, exist_ok=True)
    make(0.0, (0.82, 0.30)).save(os.path.join(out, "bg_cover_default.png"))
    make(0.05, (0.18, 0.75)).save(os.path.join(out, "bg_closing_default.png"))
    print("saved to", os.path.abspath(out))
