#!/usr/bin/env python3
"""my_mid_pptx_skill 빌더: JSON 스펙 -> 편집 가능한 PPTX (python-pptx).

사용:
    python build_deck.py --spec deck.json --out 발표자료.pptx

구성: 표지 -> 목차 -> 본문(개조식 + 표/차트/이미지 자리) -> 질문 유도 마지막 슬라이드
스펙 형식은 references/spec_schema.md 참고.
"""
import argparse
import json
import math
import os
import sys

from lxml import etree
from PIL import Image
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN, MSO_AUTO_SIZE
from pptx.enum.dml import MSO_LINE
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(HERE, "..", "assets"))

# ── 디자인 토큰 (references/design_system.md) ───────────────────────────
NAVY, DEEP, COBALT, SKY = "0D1B33", "173B6D", "2777D6", "44BCED"
WHITE, LIGHT, PALE, PAGE_BG = "FFFFFF", "DCE5F0", "E9F1FB", "F4F7FB"
BODY, MUTED, CARD_DARK, ICE = "26354C", "61738E", "142A4B", "C6D9F3"
CHART_COLORS = [COBALT, NAVY, SKY, "7F93B2", DEEP, "A9C6EE"]
# style=colorful : 섹션마다 포인트 컬러가 바뀌는 Academic 컬러 팔레트
ACCENTS = ["2777D6", "0E9384", "E0701E", "D6455D", "7B5EA7", "1BA8D6"]
COLOR_CHARTS = ["2777D6", "E0701E", "0E9384", "D6455D", "7B5EA7", "44BCED"]
FONT_HEAD, FONT_BODY = "NanumSquare", "NanumBarunGothic"
SW, SH = 13.333, 7.5

LABELS = {
    "ko": dict(agenda="목차", agenda_en="CONTENTS", presenter="발표자", source="출처",
               thanks="경청해 주셔서 감사합니다", closing="질문과 토론",
               prompts="함께 이야기하고 싶은 질문",
               affil="한림대학교 생명과학과"),
    "en": dict(agenda="Contents", agenda_en="CONTENTS", presenter="Presenter", source="Source",
               thanks="Thank you for your attention", closing="Questions & Discussion",
               prompts="Questions for discussion",
               affil="Dept. of Life Science, Hallym University"),
}
TYPE_LABELS = {
    "journal_club": "JOURNAL CLUB", "lab_meeting": "LAB MEETING",
    "conference": "CONFERENCE / SEMINAR", "course": "COURSE PRESENTATION",
    "thesis": "THESIS PROPOSAL / DEFENSE", "general": "PRESENTATION",
}
WARNINGS = []


def warn(msg):
    WARNINGS.append(msg)


def rgb(h):
    return RGBColor.from_string(h)


# ── 텍스트 길이 추정 (오버플로 경고용) ─────────────────────────────────
def _wide(c):
    o = ord(c)
    return 0x1100 <= o <= 0x11FF or 0x2E80 <= o <= 0xD7FF or 0xF900 <= o <= 0xFAFF or 0xFF00 <= o <= 0xFFEF


def est_lines(text, size, w_in):
    text = text.replace("**", "")
    total = 0
    for line in text.split("\n"):
        w = sum(size * (1.0 if _wide(c) else 0.56) for c in line)
        total += max(1, math.ceil(w / (w_in * 72)))
    return total


def est_height_in(paras, size, w_in, gap_pt=0, lf=1.32):
    h = 0
    for p in paras:
        h += est_lines(p, size, w_in) * size * lf + gap_pt
    return h / 72


def fit_size(paras, w_in, h_in, sizes, gap_pt=0):
    for s in sizes:
        if est_height_in(paras, s, w_in, gap_pt) <= h_in:
            return s
    return sizes[-1]


# ── 저수준 헬퍼 ──────────────────────────────────────────────────────
def style_run(r, font, size, bold, color):
    f = r.font
    f.name = font
    f.size = Pt(size)
    f.bold = bold
    f.color.rgb = rgb(color)
    rPr = r._r.get_or_add_rPr()
    for tag in ("a:ea", "a:cs"):
        for old in rPr.findall(qn(tag)):
            rPr.remove(old)
    latin = rPr.find(qn("a:latin"))
    ea = etree.SubElement(rPr, qn("a:ea"))
    ea.set("typeface", font)
    cs = etree.SubElement(rPr, qn("a:cs"))
    cs.set("typeface", font)
    if latin is not None:
        latin.addnext(ea)
        ea.addnext(cs)


def add_runs(p, text, font, size, color, bold=False, strong_color=None):
    parts = text.split("**")
    for i, part in enumerate(parts):
        if not part:
            continue
        r = p.add_run()
        r.text = part
        is_b = bold or i % 2 == 1
        style_run(r, font, size, is_b, strong_color if (i % 2 == 1 and strong_color) else color)


def tb(slide, x, y, w, h, text, *, font=FONT_BODY, size=14, bold=False, color=BODY,
       align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, line_spacing=None, name=None):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    if name:
        box.name = name
    tf = box.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anchor
    lines = text if isinstance(text, list) else text.split("\n")
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        if line_spacing:
            p.line_spacing = line_spacing
        add_runs(p, line, font, size, color, bold)
    return box


def rect(slide, x, y, w, h, fill=None, line=None, shape=MSO_SHAPE.RECTANGLE, alpha=None,
         radius=None, name=None, line_w=1.0, dash=False):
    s = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    if name:
        s.name = name
    s.shadow.inherit = False
    _strip_style(s)
    if fill:
        s.fill.solid()
        s.fill.fore_color.rgb = rgb(fill)
        if alpha is not None:
            clr = s.fill._xPr.find(qn("a:solidFill")).find(qn("a:srgbClr"))
            a = etree.SubElement(clr, qn("a:alpha"))
            a.set("val", str(int(alpha * 100000)))
    else:
        s.fill.background()
    if line:
        s.line.color.rgb = rgb(line)
        s.line.width = Pt(line_w)
        if dash:
            s.line.dash_style = MSO_LINE.DASH
    else:
        s.line.fill.background()
    if radius is not None and shape == MSO_SHAPE.ROUNDED_RECTANGLE:
        s.adjustments[0] = radius
    return s


def _strip_style(shape):
    st = shape._element.find(qn("p:style"))
    if st is not None:
        shape._element.remove(st)


def line_h(slide, x1, x2, y, color, width=0.75, name="선"):
    ln = slide.shapes.add_connector(1, Inches(x1), Inches(y), Inches(x2), Inches(y))
    _strip_style(ln)
    ln.line.color.rgb = rgb(color)
    ln.line.width = Pt(width)
    ln.name = name
    return ln


def set_bg(slide, color):
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = rgb(color)


def cover_picture(slide, path, name="배경 이미지"):
    with Image.open(path) as im:
        iw, ih = im.size
    pic = slide.shapes.add_picture(path, 0, 0, Inches(SW), Inches(SH))
    pic.name = name
    target, cur = SW / SH, iw / ih
    if cur > target:        # 가로가 넓음 -> 좌우 크롭
        c = (1 - target / cur) / 2
        pic.crop_left = pic.crop_right = c
    elif cur < target:      # 세로가 큼 -> 상하 크롭
        c = (1 - cur / target) / 2
        pic.crop_top = pic.crop_bottom = c
    return pic


def add_bullets(slide, x, y, w, h, items, sizes=(20, 18, 17, 16, 15, 14), gap=9, accent=COBALT, name="개조식 본문"):
    flat = []
    for it in items:
        if isinstance(it, list):
            flat += ["   " + s for s in it]
        else:
            flat.append(it)
    size = fit_size(flat, w - 0.4, h, list(sizes), gap_pt=gap)
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    box.name = name
    tf = box.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    first = True
    for it in items:
        subs = it if isinstance(it, list) else None
        entries = [(s, 1) for s in subs] if subs else [(it, 0)]
        for text, lvl in entries:
            p = tf.paragraphs[0] if first else tf.add_paragraph()
            first = False
            p.space_after = Pt(gap if lvl == 0 else 5)
            p.line_spacing = 1.1
            sz = size if lvl == 0 else max(size - 3, 12)
            add_runs(p, text, FONT_BODY, sz, BODY if lvl == 0 else MUTED, strong_color=NAVY)
            pPr = p._p.get_or_add_pPr()
            marL = Inches(0.34 + 0.34 * lvl)
            pPr.set("marL", str(int(marL)))
            pPr.set("indent", str(-int(Inches(0.3))))
            buClr = etree.SubElement(pPr, qn("a:buClr"))
            clr = etree.SubElement(buClr, qn("a:srgbClr"))
            clr.set("val", accent if lvl == 0 else MUTED)
            buFont = etree.SubElement(pPr, qn("a:buFont"))
            buFont.set("typeface", "Arial")
            buChar = etree.SubElement(pPr, qn("a:buChar"))
            buChar.set("char", "•" if lvl == 0 else "–")
    return box


# ── 공통 프레임 ─────────────────────────────────────────────────────
class Ctx:
    def __init__(self, meta, total):
        self.meta = meta
        self.total = total
        self.lang = meta.get("language", "ko")
        self.L = LABELS.get(self.lang, LABELS["ko"])
        self.type_label = meta.get("type_label") or TYPE_LABELS.get(meta.get("type", "general"), "PRESENTATION")
        self.presenter = meta.get("presenter", "이종건")
        self.affil = meta.get("affiliation", self.L["affil"])
        self.date = meta.get("date", "")
        self.n = 0
        self.colorful = meta.get("style") == "colorful"
        self.sec = {}
        self.cur_accent = COBALT

    def accent(self, section):
        if not self.colorful:
            return COBALT
        if section not in self.sec:
            self.sec[section] = ACCENTS[len(self.sec) % len(ACCENTS)]
        return self.sec[section]

    def chart_colors(self, acc):
        if not self.colorful:
            return CHART_COLORS
        rest = [c for c in COLOR_CHARTS if c != acc]
        return [acc] + rest

    def footer_text(self):
        return "  |  ".join(s for s in (self.affil, self.presenter, self.date) if s)


def frame(prs, ctx, section, title, message=None, source=None, notes=None, footer_x=0.62, bg=PAGE_BG):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    ctx.n += 1
    set_bg(slide, bg)
    acc = ctx.accent(section) if section else COBALT
    ctx.cur_accent = acc
    rect(slide, 0, 0, SW, 0.12, fill=acc, name="상단 바")
    top = f"{ctx.type_label}  /  {section}" if section else ctx.type_label
    tb(slide, footer_x, 0.27, min(9, SW - footer_x - 0.6), 0.22, top, size=10, bold=True, color=acc, name="섹션 표기")
    if len(title) > (30 if ctx.lang == "ko" else 60):
        warn(f"[슬라이드 {ctx.n}] 제목이 깁니다({len(title)}자): {title}")
    tsize = 27 if est_lines(title, 27, SW - footer_x - 0.6) == 1 else 22
    tb(slide, footer_x, 0.62, SW - footer_x - 0.6, 0.7, title, font=FONT_HEAD, size=tsize, bold=True,
       color=NAVY, anchor=MSO_ANCHOR.MIDDLE, name="제목")
    if message:
        tb(slide, footer_x, 1.40, SW - footer_x - 0.6, 0.4, message, size=15, color=MUTED, name="핵심 메시지")
    if source:
        tb(slide, footer_x, 6.62, SW - footer_x - 0.6, 0.3, source, size=10, color=MUTED, name="출처")
    line_h(slide, footer_x, SW - 0.62, 7.08, LIGHT, name="푸터 선")
    tb(slide, footer_x, 7.15, min(9, SW - footer_x - 2.0), 0.2, ctx.footer_text(), size=9, color=MUTED, name="푸터")
    tb(slide, SW - 0.62 - 1.2, 7.15, 1.2, 0.2, f"{ctx.n} / {ctx.total}", size=9, color=MUTED,
       align=PP_ALIGN.RIGHT, name="페이지")
    if notes:
        slide.notes_slide.notes_text_frame.text = notes
    return slide


# ── 시각자료: 표 / 차트 / 이미지 / 자리표시자 ──────────────────────────
def caption(slide, x, y, w, text):
    tb(slide, x, y, w, 0.3, text, size=11, color=MUTED, name="캡션")


def visual_table(slide, v, x, y, w, h, acc=COBALT, ctx=None):
    cols, rows = v["columns"], v["rows"]
    cap = v.get("caption")
    ch = 0.34 if cap else 0
    nrows, ncols = len(rows) + 1, len(cols)
    if nrows > 9 or ncols > 7:
        warn(f"표가 큽니다({nrows}행×{ncols}열). 핵심만 남기세요.")
    fs = 16 if (nrows <= 5 and ncols <= 3) else (14 if (nrows <= 6 and ncols <= 4) else 12)
    row_h = min(0.85 if nrows <= 5 else 0.6, (h - ch) / nrows)
    gf = slide.shapes.add_table(nrows, ncols, Inches(x), Inches(y), Inches(w), Inches(row_h * nrows))
    gf.name = "표"
    tbl = gf.table
    tbl.first_row = True
    tbl.horz_banding = False
    widths = v.get("col_widths")
    for i in range(ncols):
        tbl.columns[i].width = Inches(w * (widths[i] if widths else 1 / ncols))
    for r in range(nrows):
        tbl.rows[r].height = Inches(row_h)
        for c in range(ncols):
            cell = tbl.cell(r, c)
            txt = str(cols[c] if r == 0 else rows[r - 1][c])
            cell.fill.solid()
            cell.fill.fore_color.rgb = rgb(NAVY if r == 0 else (WHITE if r % 2 else PALE))
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.margin_left = cell.margin_right = Inches(0.1)
            tf = cell.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT if c == 0 else PP_ALIGN.CENTER
            add_runs(p, txt, FONT_BODY, fs, WHITE if r == 0 else BODY, bold=(r == 0 or c == 0),
                     strong_color=NAVY)
    if cap:
        caption(slide, x, y + row_h * nrows + 0.1, w, cap)


def visual_chart(slide, v, x, y, w, h, acc=COBALT, ctx=None):
    kind = v.get("chart_type", "bar")
    cap = v.get("caption")
    ch = 0.34 if cap else 0
    rect(slide, x, y, w, h - ch, fill=WHITE, name="차트 카드")
    cd = CategoryChartData()
    cd.categories = v["categories"]
    for s in v["series"]:
        cd.add_series(s["name"], s["values"])
    ct = {"bar": XL_CHART_TYPE.COLUMN_CLUSTERED, "hbar": XL_CHART_TYPE.BAR_CLUSTERED,
          "line": XL_CHART_TYPE.LINE_MARKERS, "pie": XL_CHART_TYPE.PIE,
          "stacked": XL_CHART_TYPE.COLUMN_STACKED}[kind]
    gf = slide.shapes.add_chart(ct, Inches(x + 0.15), Inches(y + 0.1), Inches(w - 0.3), Inches(h - ch - 0.2), cd)
    gf.name = "차트"
    chart = gf.chart
    chart.font.size = Pt(12)
    chart.font.name = FONT_BODY
    chart.font.color.rgb = rgb(BODY)
    if v.get("title"):
        chart.has_title = True
        chart.chart_title.text_frame.text = v["title"]
        r = chart.chart_title.text_frame.paragraphs[0].runs[0]
        style_run(r, FONT_BODY, 13, True, NAVY)
        chart.chart_title.include_in_layout = False
    else:
        chart.has_title = False
    multi = len(v["series"]) > 1
    chart.has_legend = multi or kind == "pie"
    if chart.has_legend:
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(12)
    plot = chart.plots[0]
    plot.has_data_labels = v.get("data_labels", True)
    if plot.has_data_labels:
        dl = plot.data_labels
        dl.font.size = Pt(11)
        dl.number_format = v.get("number_format", "General")
        dl.number_format_is_linked = False
        dl.position = {"bar": XL_LABEL_POSITION.OUTSIDE_END, "hbar": XL_LABEL_POSITION.OUTSIDE_END,
                       "line": XL_LABEL_POSITION.ABOVE, "stacked": XL_LABEL_POSITION.CENTER,
                       "pie": XL_LABEL_POSITION.OUTSIDE_END}[kind]
    pal = ctx.chart_colors(acc) if ctx else CHART_COLORS
    if kind == "pie":
        for i, pt in enumerate(plot.series[0].points):
            pt.format.fill.solid()
            pt.format.fill.fore_color.rgb = rgb(pal[i % len(pal)])
    else:
        if kind in ("bar", "hbar", "stacked"):
            plot.gap_width = 70
        for i, s in enumerate(plot.series):
            col = rgb(pal[i % len(pal)])
            if kind == "line":
                s.format.line.color.rgb = col
                s.format.line.width = Pt(2.5)
                s.smooth = False
                s.marker.format.fill.solid()
                s.marker.format.fill.fore_color.rgb = col
                s.marker.format.line.color.rgb = col
            else:
                s.format.fill.solid()
                s.format.fill.fore_color.rgb = col
        va, ca = chart.value_axis, chart.category_axis
        va.has_major_gridlines = True
        va.major_gridlines.format.line.color.rgb = rgb(LIGHT)
        va.format.line.fill.background()
        va.tick_labels.font.size = Pt(11)
        ca.tick_labels.font.size = Pt(12)
        ca.format.line.color.rgb = rgb(LIGHT)
        if "y_min" in v:
            va.minimum_scale = v["y_min"]
        elif kind != "line":
            va.minimum_scale = 0       # 막대 그래프는 원점 0 (차이 과장 방지)
        if "y_max" in v:
            va.maximum_scale = v["y_max"]
        if v.get("unit"):
            va.has_title = True
            va.axis_title.text_frame.text = v["unit"]
            style_run(va.axis_title.text_frame.paragraphs[0].runs[0], FONT_BODY, 11, False, MUTED)
    if cap:
        caption(slide, x, y + h - ch + 0.06, w, cap)


def visual_image(slide, v, x, y, w, h, acc=COBALT, ctx=None):
    cap = v.get("caption")
    ch = 0.34 if cap else 0
    rect(slide, x, y, w, h - ch, fill=WHITE, name="이미지 카드")
    path = v["path"]
    if not os.path.exists(path):
        warn(f"이미지 파일을 찾을 수 없습니다: {path} -> 자리표시자로 대체")
        return visual_placeholder(slide, {"label": os.path.basename(path)}, x, y, w, h, acc, ctx)
    with Image.open(path) as im:
        iw, ih = im.size
    bw, bh = w - 0.3, h - ch - 0.3
    sc = min(bw / iw, bh / ih)
    pw, ph = iw * sc, ih * sc
    pic = slide.shapes.add_picture(path, Inches(x + (w - pw) / 2), Inches(y + (h - ch - ph) / 2),
                                   Inches(pw), Inches(ph))
    pic.name = "그림"
    if cap:
        caption(slide, x, y + h - ch + 0.06, w, cap)


def visual_placeholder(slide, v, x, y, w, h, acc=COBALT, ctx=None):
    cap = v.get("caption")
    ch = 0.34 if cap else 0
    rect(slide, x, y, w, h - ch, fill=WHITE, line=MUTED, shape=MSO_SHAPE.ROUNDED_RECTANGLE,
         radius=0.03, dash=True, name="그림/표 자리")
    tb(slide, x + 0.3, y, w - 0.6, h - ch, ["[ 그림 · 표 · 차트 삽입 위치 ]", v.get("label", "")],
       size=15, color=MUTED, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, name="자리표시자 안내")
    if cap:
        caption(slide, x, y + h - ch + 0.06, w, cap)


VISUALS = {"table": visual_table, "chart": visual_chart, "image": visual_image,
           "placeholder": visual_placeholder}


# ── 슬라이드 종류 ────────────────────────────────────────────────────
def side_bar(slide, ctx):
    if ctx.colorful:
        seg = SH / len(ACCENTS)
        for i, c in enumerate(ACCENTS):
            rect(slide, 0, i * seg, 0.18, seg + 0.01, fill=c, name=f"컬러 바 {i + 1}")
    else:
        rect(slide, 0, 0, 0.18, SH, fill=COBALT, name="좌측 포인트 바")


def build_cover(prs, ctx):
    m = ctx.meta
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    ctx.n += 1
    img = m.get("cover_image")
    custom = bool(img) and os.path.exists(img)
    if img and not custom:
        warn(f"표지 이미지를 찾을 수 없어 기본 배경을 사용합니다: {img}")
    cover_picture(slide, img if custom else os.path.join(ASSETS, "bg_cover_default.png"))
    if custom:
        rect(slide, 0, 0, 8.9, SH, fill=NAVY, alpha=0.86, name="텍스트 가독성 오버레이")
    side_bar(slide, ctx)
    tb(slide, 0.85, 0.72, 8, 0.3, ctx.type_label, size=14, bold=True, color=SKY, name="발표 유형")
    title = m["title"]
    tw = 7.6
    size = 34
    while size > 24 and est_lines(title, size, tw) > 3:
        size -= 2
    tb(slide, 0.85, 1.55, tw, 2.2, title, font=FONT_HEAD, size=size, bold=True, color=WHITE,
       line_spacing=1.1, name="발표 제목")
    if m.get("subtitle"):
        tb(slide, 0.87, 3.95, tw, 1.0, m["subtitle"], size=18, color=ICE, name="부제")
    rect(slide, 0.87, 5.45, 0.9, 0.05, fill=SKY, name="구분선")
    L = ctx.L
    tb(slide, 0.87, 5.7, 8, 0.4, f"{L['presenter']}  {ctx.presenter}", size=20, bold=True, color=WHITE,
       name="발표자")
    info = "  •  ".join(s for s in (ctx.affil, m.get("term"), ctx.date) if s)
    tb(slide, 0.87, 6.2, 9, 0.3, info, size=12, color=ICE, name="소속·일시")
    if m.get("event"):
        tb(slide, 0.87, 6.58, 9, 0.3, m["event"], size=12, color=ICE, name="행사/수업명")
    if m.get("notes"):
        slide.notes_slide.notes_text_frame.text = m["notes"]


def build_agenda(prs, ctx, items):
    L = ctx.L
    slide = frame(prs, ctx, "", L["agenda"], footer_x=4.9)
    # 좌측 네이비 패널로 덮기 (프레임 위 요소 재배치)
    for shp in list(slide.shapes):
        if shp.name in ("제목", "섹션 표기"):
            shp._element.getparent().remove(shp._element)
    rect(slide, 0, 0.12, 4.3, SH - 0.12, fill=NAVY, name="좌측 패널")
    rect(slide, 0.62, 2.55, 0.8, 0.05, fill=SKY, name="구분선")
    tb(slide, 0.62, 2.8, 3.4, 0.8, L["agenda"], font=FONT_HEAD, size=36, bold=True, color=WHITE, name="제목")
    tb(slide, 0.62, 3.65, 3.4, 0.3, L["agenda_en"], size=14, bold=True, color=SKY, name="영문 라벨")
    n = len(items)
    if n > 8:
        warn(f"목차 항목이 {n}개입니다. 8개 이하를 권장합니다.")
    top, bottom = 1.15, 6.7
    row_h = min(0.85, (bottom - top) / n)
    fs = 22 if n <= 6 else 19
    for i, t in enumerate(items):
        yy = top + i * row_h
        oval = rect(slide, 4.9, yy + (row_h - 0.52) / 2, 0.52, 0.52, fill=ctx.accent(t) if ctx.colorful else COBALT, shape=MSO_SHAPE.OVAL,
                    name=f"목차 번호 {i + 1}")
        tf = oval.text_frame
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        add_runs(p, f"{i + 1}", FONT_BODY, 16, WHITE, bold=True)
        tb(slide, 5.7, yy, 7.0, row_h, t, font=FONT_BODY, size=fs, bold=True, color=NAVY,
           anchor=MSO_ANCHOR.MIDDLE, name=f"목차 항목 {i + 1}")
        if i < n - 1:
            line_h(slide, 5.7, SW - 0.62, yy + row_h, LIGHT, name=f"목차 구분선 {i + 1}")


def build_content(prs, ctx, s):
    slide = frame(prs, ctx, s.get("section", ""), s["title"], s.get("message"), s.get("source"), s.get("notes"))
    bullets, vis = s.get("bullets"), s.get("visual")
    n = ctx.n
    if bullets:
        if len(bullets) > 5:
            warn(f"[슬라이드 {n}] 불릿이 {len(bullets)}개입니다(권장 3~5).")
        limit = 55 if ctx.lang == "ko" else 100
        for b in bullets:
            for t in (b if isinstance(b, list) else [b]):
                if len(t) > limit:
                    warn(f"[슬라이드 {n}] 불릿이 깁니다({len(t)}자): {t[:25]}…")
    layout = s.get("layout", "auto")
    if layout == "auto":
        layout = "split" if (bullets and vis) else ("visual_only" if vis else "bullets_only")
    X, Y, H = 0.62, 2.0, 4.45
    if layout == "bullets_only":
        rect(slide, X, Y, 12.1, H, fill=WHITE, name="본문 카드")
        rect(slide, X, Y, 0.08, H, fill=ctx.cur_accent, name="포인트 바")
        add_bullets(slide, X + 0.55, Y + 0.45, 11.0, H - 0.7, bullets, sizes=(26, 24, 22, 20, 18, 16), gap=16,
                    accent=ctx.cur_accent)
    elif layout == "visual_only":
        VISUALS[vis["type"]](slide, vis, X, Y, 12.1, H, ctx.cur_accent, ctx)
    else:
        lw = 5.6
        rect(slide, X, Y, lw, H, fill=WHITE, name="본문 카드")
        rect(slide, X, Y, 0.08, H, fill=ctx.cur_accent, name="포인트 바")
        sizes = (20, 18, 17, 16, 15, 14, 13)
        h_text = H - 0.6
        add_bullets(slide, X + 0.35, Y + 0.35, lw - 0.6, h_text, bullets, sizes=sizes, gap=12,
                    accent=ctx.cur_accent)
        VISUALS[vis["type"]](slide, vis, X + lw + 0.3, Y, 12.1 - lw - 0.3, H, ctx.cur_accent, ctx)
    # 오버플로 경고
    if bullets and layout != "visual_only":
        flat = [t for b in bullets for t in (b if isinstance(b, list) else [b])]
        wi = 11.2 if layout == "bullets_only" else lw - 0.6
        hi = H - 0.6
        min_size = 14 if layout == "bullets_only" else 13
        if est_height_in(flat, min_size, wi - 0.4, 9) > hi:
            warn(f"[슬라이드 {n}] 불릿 분량이 많아 박스를 넘칠 수 있습니다. 줄이거나 슬라이드를 나누세요.")


def build_closing(prs, ctx, c):
    L = ctx.L
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    ctx.n += 1
    img = ctx.meta.get("closing_image")
    custom = bool(img) and os.path.exists(img)
    if img and not custom:
        warn(f"마지막 슬라이드 이미지를 찾을 수 없어 기본 배경을 사용합니다: {img}")
    cover_picture(slide, img if custom else os.path.join(ASSETS, "bg_closing_default.png"))
    if custom:
        rect(slide, 0, 0, SW, SH, fill=NAVY, alpha=0.78, name="가독성 오버레이")
    side_bar(slide, ctx)
    tb(slide, 0.85, 0.7, 6, 0.3, "Q & A", size=14, bold=True, color=SKY, name="라벨")
    tb(slide, 0.85, 1.15, 11, 0.9, c.get("headline", L["closing"]), font=FONT_HEAD, size=40, bold=True,
       color=WHITE, name="마지막 제목")
    tb(slide, 0.87, 2.1, 11, 0.4, c.get("message", L["thanks"]), size=18, color=ICE, name="감사 문구")
    prompts = c.get("prompts", [])
    if len(prompts) > 4:
        warn("질문 유도 문구는 4개 이하를 권장합니다.")
    if prompts:
        n = len(prompts)
        ch = 0.95 + n * 0.62
        rect(slide, 0.87, 3.0, 11.4, ch, fill=CARD_DARK, shape=MSO_SHAPE.ROUNDED_RECTANGLE, radius=0.04,
             name="질문 카드")
        tb(slide, 1.25, 3.25, 10, 0.3, c.get("prompts_title", L["prompts"]), size=15, bold=True, color=SKY,
           name="질문 카드 제목")
        for i, q in enumerate(prompts):
            tb(slide, 1.25, 3.8 + i * 0.62, 10.7, 0.5, [f"Q{i + 1}.  {q}"], size=19, color=WHITE,
               anchor=MSO_ANCHOR.MIDDLE, name=f"질문 {i + 1}")
    foot = c.get("contact") or ctx.footer_text()
    tb(slide, 0.87, 6.75, 11, 0.3, foot, size=11, color=ICE, name="연락처·푸터")
    tb(slide, SW - 0.62 - 1.2, 6.75, 1.2, 0.3, f"{ctx.n} / {ctx.total}", size=11, color=ICE,
       align=PP_ALIGN.RIGHT, name="페이지")
    if c.get("notes"):
        slide.notes_slide.notes_text_frame.text = c["notes"]


# ── 메인 ────────────────────────────────────────────────────────────
def build(spec, out):
    meta = spec["meta"]
    slides = spec["slides"]
    use_agenda = spec.get("agenda", True) is not False
    if use_agenda:
        agenda = spec["agenda"] if isinstance(spec.get("agenda"), list) else []
        if not agenda:
            for s in slides:
                sec = s.get("section")
                if sec and sec not in agenda:
                    agenda.append(sec)
        if not agenda:
            warn("목차를 만들 section 정보가 없습니다.")
    total = 1 + (1 if use_agenda else 0) + len(slides) + 1
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(SW), Inches(SH)
    ctx = Ctx(meta, total)
    prs.core_properties.title = meta["title"]
    prs.core_properties.author = ctx.presenter
    for s_ in slides:
        if s_.get("section"):
            ctx.accent(s_["section"])
    build_cover(prs, ctx)
    if use_agenda:
        build_agenda(prs, ctx, agenda)
    for s in slides:
        build_content(prs, ctx, s)
    build_closing(prs, ctx, spec.get("closing", {}))
    prs.save(out)
    return total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    with open(a.spec, encoding="utf-8") as f:
        spec = json.load(f)
    out = os.path.abspath(a.out or spec["meta"].get("output") or "presentation.pptx")
    os.chdir(os.path.dirname(os.path.abspath(a.spec)))    # 스펙 안의 상대 경로(이미지)는 스펙 파일 기준
    total = build(spec, out)
    print(f"saved: {out}  ({total} slides)")
    if WARNINGS:
        print("\n⚠ 경고:")
        for w in WARNINGS:
            print("  -", w)
    else:
        print("경고 없음")


if __name__ == "__main__":
    main()
