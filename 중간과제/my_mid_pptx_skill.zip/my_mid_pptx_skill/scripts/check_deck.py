#!/usr/bin/env python3
"""완성된 PPTX 구조 점검: 슬라이드 수, 범위 이탈, 예시/미완성 문구, 빈 슬라이드.

사용: python check_deck.py deck.pptx
"""
import re
import sys
from pptx import Presentation
from pptx.util import Emu

FLAGS = re.compile(r"\[예시|TODO|XXX|lorem|ipsum|\[확인 필요|\[insert", re.I)


def main(path):
    prs = Presentation(path)
    W, H = prs.slide_width, prs.slide_height
    issues = 0
    print(f"파일: {path}\n슬라이드 수: {len(prs.slides)}  크기: {Emu(W).inches:.2f}x{Emu(H).inches:.2f} in")
    for i, s in enumerate(prs.slides, 1):
        texts = []
        n_chart = n_table = n_pic = 0
        for sh in s.shapes:
            if sh.left is not None and (sh.left < -10000 or sh.top < -10000 or sh.left + sh.width > W + 10000
                                        or sh.top + sh.height > H + 10000):
                print(f"  ⚠ [{i}] 범위 이탈: {sh.name}")
                issues += 1
            if sh.has_text_frame and sh.text_frame.text.strip():
                texts.append(sh.text_frame.text.strip().replace("\n", " / "))
            n_chart += getattr(sh, "has_chart", False) and sh.has_chart
            n_table += getattr(sh, "has_table", False) and sh.has_table
            n_pic += sh.shape_type == 13
        title = next((sh.text_frame.text for sh in s.shapes if sh.name in ("제목", "발표 제목", "마지막 제목")), "")
        print(f"[{i}] {title.splitlines()[0] if title else '(제목 없음)'}  | 차트 {n_chart} 표 {n_table} 그림 {n_pic}")
        if not texts:
            print(f"  ⚠ [{i}] 텍스트 없음")
            issues += 1
        for t in texts:
            if FLAGS.search(t):
                print(f"  ℹ [{i}] 교체 필요 문구: {t[:60]}")
                issues += 1
    print(f"\n점검 항목 {issues}건" if issues else "\n이상 없음")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("사용: python check_deck.py deck.pptx")
    main(sys.argv[1])
