# 스펙(JSON) 형식

```json
{
  "meta": {
    "type": "journal_club | lab_meeting | conference | course | thesis | general",
    "language": "ko | en",
    "title": "발표 제목 (줄바꿈 \\n 가능, 3줄 이내)",
    "subtitle": "부제 / 저자·저널·연도",
    "presenter": "이종건",
    "affiliation": "한림대학교 생명과학과",
    "term": "2026년 2학기",
    "date": "2026.10.21",
    "event": "행사/수업/랩미팅명 (선택)",
    "cover_image": "경로 또는 null",
    "closing_image": "경로 또는 null",
    "type_label": "상단 표기 직접 지정 (선택)"
  },
  "agenda": true,
  "slides": [ { ...본문 슬라이드... } ],
  "closing": { "headline": "질문과 토론", "message": "경청해 주셔서 감사합니다",
               "prompts": ["질문1", "질문2"], "contact": "email@..." }
}
```
- `agenda`: `true`(기본, section 자동 수집) / `false`(목차 생략) / `["항목1", ...]`(직접 지정)
- 이미지 상대 경로는 **스펙 파일이 있는 폴더 기준**.

## 본문 슬라이드
```json
{
  "section": "목차에 표시될 이름 (같은 이름이면 한 항목으로 묶임)",
  "title": "결론형 제목 (≤ 30자)",
  "message": "핵심 메시지 한 줄",
  "bullets": ["**강조어**: 설명", ["하위 불릿1", "하위 불릿2"]],
  "visual": { ... },
  "layout": "auto | bullets_only | split | visual_only",
  "source": "출처: Author et al. (2026), Fig. 2 [1]",
  "notes": "발표자 노트 (대본·예상 질문)"
}
```
`**텍스트**`는 굵게. 리스트(`[...]`)는 바로 앞 불릿의 하위 불릿. `layout=auto`: 불릿+visual → split, visual만 → visual_only, 불릿만 → bullets_only.

## visual 종류
- 표: `{"type":"table","columns":[...],"rows":[[...]],"col_widths":[0.3,0.35,0.35],"caption":"Table 1. ..."}`
- 차트: `{"type":"chart","chart_type":"bar|hbar|line|pie|stacked","categories":[...],"series":[{"name":"","values":[]}],"unit":"y축 단위","title":"","number_format":"0.0","y_min":0,"y_max":10,"caption":""}`
  - 편집 가능한 PowerPoint 기본 차트로 생성됨. 막대형 y축은 0 시작(y_min으로 변경 가능하나 차이 과장 주의).
- 이미지: `{"type":"image","path":"fig2.png","caption":"Figure 2. ..."}` (비율 유지, 파일 없으면 자리표시자)
- 자리표시자: `{"type":"placeholder","label":"Figure 1. 실험 설계 모식도","caption":"..."}`
