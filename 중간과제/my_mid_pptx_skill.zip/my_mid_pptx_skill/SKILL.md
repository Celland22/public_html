---
name: my_mid_pptx_skill
description: 한림대학교 생명과학과 대학원생 이종건의 학교생활용 PowerPoint(.pptx) 제작 스킬. 논문 리뷰/저널클럽, 랩미팅·연구 진행 보고, 학회·세미나 발표, 수업 과제·중간/기말 발표, 학위논문 계획·심사 자료를 만들 때 반드시 사용한다. 첫 슬라이드는 발표제목·발표자, 둘째는 목차, 마지막은 질문 유도(Q&A), 그 사이는 개조식 간결 텍스트 + 표·차트 자리로 구성한다. 사용자가 "발표자료", "PPT", "슬라이드", "저널클럽", "랩미팅", "세미나", "발표 준비", "pptx"를 언급하면 파일 형식을 말하지 않아도 이 스킬을 사용한다. 발표 내용·주제·청중이 정해지지 않았으면 먼저 질문(grill-me 방식)으로 확정한 뒤 제작한다.
---

# my_mid_pptx_skill — 이종건 대학원 발표자료 스킬

한림대학교 생명과학과 **이종건**이 대학원 생활에서 만드는 발표자료를, 업로드된 중간고사 발표자료(`assets/reference_template.pptx`)의 네이비·코발트 디자인으로 일관되게 만든다.
결과물은 **텍스트·표·차트가 모두 편집 가능한 PPTX**이다 (슬라이드를 통째로 이미지로 넣지 않는다).

## 고정 구성 (바꾸지 않는다)

| 순서 | 슬라이드 | 내용 |
|---|---|---|
| 1 | 표지 | 발표 제목 · 발표자(이종건) · 소속/학기/날짜 · (선택) 부제, 행사/수업명 |
| 2 | 목차 | 본문 section을 자동 번호로 나열 (≤ 8개) |
| 3…N-1 | 본문 | 제목 + 핵심 메시지 1줄 + **개조식 불릿 3~5개** + 표/차트/그림 자리 + 출처 줄 |
| N | 마지막 | "질문과 토론" + 질문 유도 문구 2~4개 (Q1, Q2…) |

## 작업 절차

### 1단계. 인터뷰 (grill-me) — 먼저 확정한다
대화에서 이미 알 수 있는 것은 묻지 않는다. 모르는 것만 `ask_user_input_v0`(가능하면)로 한 번에 1~3문항씩 묻는다. 체크리스트와 질문 예시는 `references/interview_checklist.md`.
필수 확정: ① 발표 유형 ② 제목·주제 ③ 발표 시간/장수 ④ 핵심 내용(논문 PDF, 데이터, 메모 중 무엇을 줄지) ⑤ 날짜 ⑥ **표지·마지막 배경 이미지**(매번 요청; 없으면 기본 그라데이션) ⑦ 언어(자동 판단 규칙은 `references/writing_rules.md`).

### 2단계. 아웃라인 제시 → 승인
슬라이드별 `section / 제목 / 핵심 메시지 / 불릿 요지 / 시각자료 종류`를 표로 보여주고 승인받는다. 유형별 표준 흐름은 `references/presentation_types.md`.

### 3단계. 스펙(JSON) 작성 → 빌드
- 스펙 형식: `references/spec_schema.md`, 예시: `assets/example_spec.json`
- 글쓰기 규칙(개조식, 글자 수, 출처 표기): `references/writing_rules.md`
- 디자인 토큰·좌표: `references/design_system.md`

```bash
python scripts/build_deck.py --spec deck.json --out /mnt/user-data/outputs/발표자료.pptx
```
필요 라이브러리: `python-pptx`, `Pillow`, `numpy`, `lxml` (`pip install python-pptx pillow numpy --break-system-packages`).
기본 배경이 없으면 `python scripts/gen_background.py`로 다시 만든다.

### 4단계. 점검 (필수)
```bash
python scripts/check_deck.py /mnt/user-data/outputs/발표자료.pptx   # 범위 이탈·예시 문구 잔존·빈 슬라이드
bash scripts/render_preview.sh /mnt/user-data/outputs/발표자료.pptx # PDF/JPG 미리보기 (LibreOffice 필요)
```
미리보기 이미지를 **직접 열어** 글자 넘침, 겹침, 줄바꿈 어색함을 확인하고 고친 뒤 다시 빌드한다. `build_deck.py`가 출력하는 ⚠ 경고도 해결한다.

### 5단계. 전달
`present_files`로 pptx를 공유하고, 가정한 사항(예: 가상 데이터, 비워 둔 자리표시자)을 1~3줄로 알린다.

## 절대 규칙
- 사실·수치·참고문헌을 **지어내지 않는다.** 근거가 없으면 `[예시]`/자리표시자로 두고 알린다. 논문 리뷰는 원문에 있는 내용만 쓴다.
- 본문은 **개조식**(명사형 종결, 한 불릿 ≤ 55자), 한 슬라이드 불릿 **3~5개**.
- 모든 표·차트·그림에 **단위, 연도/조건, 출처**를 표시한다. 막대 차트 y축은 0에서 시작한다.
- 배경 이미지는 표지·마지막 슬라이드에만 쓴다. 이미지 파일이 없으면 기본 네이비 그라데이션을 쓴다.
- 폰트: 제목 `NanumSquare`, 본문 `NanumBarunGothic` (미설치 PC에서는 PowerPoint가 대체 폰트로 표시할 수 있음 → 발표 PC에 설치 안내).
- 파일명 기본값: `학번_주제_발표자료.pptx` 형태를 제안하되, 사용자가 지정하면 따른다.

## 파일 구성
- `scripts/build_deck.py` — JSON → PPTX 빌더 (표지/목차/본문/마지막)
- `scripts/gen_background.py` — 기본 그라데이션 배경 생성
- `scripts/check_deck.py` — 완성된 PPTX 구조 점검
- `scripts/render_preview.sh` — PDF/JPG 미리보기
- `assets/` — 기본 배경 2종, 예시 스펙, 원본 참고 PPTX
- `references/` — 인터뷰·스펙·글쓰기·디자인·유형별 구성 문서
